# Flavour Fusion: AI-Driven Recipe Blog Generator

Flavour Fusion is a Gradio-based web app that uses GPT-2 (via Hugging Face Transformers) to generate AI-powered recipe blog posts. Built to run in Google Colab, Hugging Face Spaces, or locally.

## Features

- Generate full recipe blogs with intro, ingredients, instructions, tips, and nutrition info
- Customize blog length with word count slider
- Enjoy a random programmer joke while waiting
- No OpenAI API key needed

## Installation

```bash
pip install -r requirements.txt
python flavour_fusion.py
```

## Run Locally

After installing dependencies, simply run:

```bash
python flavour_fusion.py
```

## Hosting Options

- Google Colab
- Hugging Face Spaces (recommended for free cloud hosting)
- Your local machine

## License

MIT
